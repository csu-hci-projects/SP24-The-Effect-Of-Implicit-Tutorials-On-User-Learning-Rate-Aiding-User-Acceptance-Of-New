GitHub: https://github.com/csu-hci-projects/SP24-The-Effect-Of-Implicit-Tutorials-On-User-Learning-Rate-Aiding-User-Acceptance-Of-New/tree/main 

Overview Video: https://youtu.be/rp9c-zA3h5c

Code Explanation Video: https://youtu.be/rZKI5KsRYxc

Due to the way that we coded the file system, the project could not be built, so it must be openned in the Unity Editor. 
We coded the project in Unity version 2022.3.10f1, but related versions should also support the project.
When running the program in play mode, please set the game view settings to 16:9 aspect ratio and maximized.

The file directory the text files with participant data are stored in will be printed to the console, and can be used to locate the results files.
When you first run the project, you will be prompted with two textboxes. For the first textbox, type in your participant's ID. For the second textbox, 
you will indicate which tutorial mode the participant will be engaging with. 

```
For standard/video tutorial----type stut
For highlighted tutorial-------type htut
For no tutorial----------------type notut
```

When running the standard tutorial, please use the special standard tutorial powerpoint found in Miscellaneous for the video tutorials. Make sure the participant
clicks start before they start each video to ensure accurate timing.
